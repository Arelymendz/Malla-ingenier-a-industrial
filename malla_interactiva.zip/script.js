const materias = [
  // Primer año
  // I Semestre
  { id: 'investigacion', nombre: 'Investigación en ingeniería', uv: 4, requisitos: [], desbloquea: ['fisica1'], semestre: 1 },
  { id: 'matematica1', nombre: 'Matemática I', uv: 4, requisitos: [], desbloquea: ['matematica2', 'fisica1'], semestre: 1 },
  { id: 'psicologia', nombre: 'Psicología y relaciones sociolaborales', uv: 4, requisitos: [], desbloquea: ['responsabilidad'], semestre: 1 },
  { id: 'dibujo1', nombre: 'Dibujo técnico I', uv: 3, requisitos: [], desbloquea: ['dibujo2'], semestre: 1 },
  { id: 'introIng', nombre: 'Introducción a la ingeniería Industrial', uv: 4, requisitos: [], desbloquea: ['ofimatica', 'logica'], semestre: 1 },

  // II Semestre
  { id: 'fisica1', nombre: 'Física I', uv: 4, requisitos: ['investigacion', 'matematica1'], desbloquea: ['fisica2', 'solidos'], semestre: 2 },
  { id: 'matematica2', nombre: 'Matemática II', uv: 4, requisitos: ['matematica1'], desbloquea: ['matematica3', 'fisica2', 'solidos'], semestre: 2 },
  { id: 'responsabilidad', nombre: 'Responsabilidad de la ingeniería en la economía y la sociedad', uv: 4, requisitos: ['psicologia'], desbloquea: ['admin'], semestre: 2 },
  { id: 'quimica', nombre: 'Química técnica', uv: 4, requisitos: [], desbloquea: ['teci1'], semestre: 2 },
  { id: 'dibujo2', nombre: 'Dibujo técnico II', uv: 4, requisitos: ['dibujo1'], desbloquea: ['teci1'], semestre: 2 },

  // Segundo año
  // III Semestre
  { id: 'fisica2', nombre: 'Física II', uv: 4, requisitos: ['fisica1', 'matematica2'], desbloquea: ['fisica3', 'dinamica', 'fluidos'], semestre: 3 },
  { id: 'matematica3', nombre: 'Matemática III', uv: 4, requisitos: ['matematica2'], desbloquea: ['fisica3', 'matematica4', 'economia', 'probabilidad'], semestre: 3 },
  { id: 'ofimatica', nombre: 'Ofimática y software para ingeniería industrial', uv: 4, requisitos: ['introIng'], desbloquea: ['ingeconomica'], semestre: 3 },
  { id: 'logica', nombre: 'Lógica y algoritmos', uv: 4, requisitos: ['introIng'], desbloquea: ['probabilidad'], semestre: 3 },
  { id: 'solidos', nombre: 'Sólidos deformables', uv: 4, requisitos: ['fisica1', 'matematica2'], desbloquea: ['dinamica', 'teci2'], semestre: 3 },

  // IV Semestre
  { id: 'fisica3', nombre: 'Física III', uv: 4, requisitos: ['fisica2', 'matematica3'], desbloquea: ['eficiencia'], semestre: 4 },
  { id: 'matematica4', nombre: 'Matemática IV', uv: 4, requisitos: ['matematica3'], desbloquea: ['fluidos'], semestre: 4 },
  { id: 'dinamica', nombre: 'Dinámica', uv: 4, requisitos: ['fisica2', 'solidos'], desbloquea: ['eficiencia'], semestre: 4 },
  { id: 'admin', nombre: 'Fundamentos de administración', uv: 4, requisitos: ['responsabilidad'], desbloquea: ['calidad'], semestre: 4 },
  { id: 'teci1', nombre: 'Tecnología industrial I', uv: 4, requisitos: ['quimica', 'dibujo2'], desbloquea: ['teci2'], semestre: 4 },

  // Tercer año
  // V Semestre
  { id: 'fluidos', nombre: 'Mecánica de los fluidos', uv: 4, requisitos: ['fisica2', 'matematica4'], desbloquea: ['seguridad'], semestre: 5 },
  { id: 'economia', nombre: 'Fundamentos de economía', uv: 4, requisitos: ['matematica3'], desbloquea: ['ingeconomica'], semestre: 5 },
  { id: 'eficiencia', nombre: 'Eficiencia energética', uv: 4, requisitos: ['fisica3', 'dinamica'], desbloquea: ['teci3'], semestre: 5 },
  { id: 'probabilidad', nombre: 'Probabilidad y estadística', uv: 4, requisitos: ['logica', 'matematica3'], desbloquea: ['investigacion1', 'calidad'], semestre: 5 },
  { id: 'teci2', nombre: 'Tecnología industrial II', uv: 4, requisitos: ['solidos', 'teci1'], desbloquea: ['teci3', 'seguridad'], semestre: 5 },

  // VI Semestre
  { id: 'ingeconomica', nombre: 'Ingeniería económica', uv: 4, requisitos: ['ofimatica', 'economia'], desbloquea: ['contabilidad', 'investigacion2'], semestre: 6 },
  { id: 'investigacion1', nombre: 'Investigación de operaciones I', uv: 4, requisitos: ['probabilidad'], desbloquea: ['investigacion2'], semestre: 6 },
  { id: 'calidad', nombre: 'Gestión de la calidad', uv: 4, requisitos: ['admin', 'probabilidad'], desbloquea: ['organizacion'], semestre: 6 },
  { id: 'seguridad', nombre: 'Seguridad y salud ocupacional', uv: 4, requisitos: ['fluidos', 'teci2'], desbloquea: ['capital'], semestre: 6 },
  { id: 'teci3', nombre: 'Tecnología industrial III', uv: 4, requisitos: ['eficiencia', 'teci2'], desbloquea: ['metodos'], semestre: 6 },

  // Cuarto año
  // VII Semestre
  { id: 'capital', nombre: 'Gestión del capital humano', uv: 4, requisitos: ['seguridad'], desbloquea: [], semestre: 7 },
  { id: 'contabilidad', nombre: 'Contabilidad y costos', uv: 4, requisitos: ['ingeconomica'], desbloquea: ['financiera'], semestre: 7 },
  { id: 'investigacion2', nombre: 'Investigación de operaciones II', uv: 4, requisitos: ['ingeconomica', 'investigacion1'], desbloquea: ['cadena'], semestre: 7 },
  { id: 'organizacion', nombre: 'Análisis y diseño organizacional', uv: 4, requisitos: ['calidad'], desbloquea: ['mercadeo'], semestre: 7 },
  { id: 'metodos', nombre: 'Ingeniería de métodos', uv: 4, requisitos: ['teci3'], desbloquea: ['cadena', 'plantas', 'medidas'], semestre: 7 },

  // VIII Semestre
  { id: 'mercadeo', nombre: 'Mercadeo', uv: 4, requisitos: ['organizacion'], desbloquea: ['proyectos'], semestre: 8 },
  { id: 'financiera', nombre: 'Administración financiera', uv: 4, requisitos: ['contabilidad'], desbloquea: ['proyectos'], semestre: 8 },
  { id: 'cadena', nombre: 'Gestión de la cadena de suministros', uv: 4, requisitos: ['investigacion2', 'metodos'], desbloquea: ['produccion'], semestre: 8 },
  { id: 'plantas', nombre: 'Distribución en plantas', uv: 4, requisitos: ['metodos'], desbloquea: ['produccion', 'proyectos'], semestre: 8 },
  { id: 'medidas', nombre: 'Medidas del trabajo', uv: 4, requisitos: ['metodos'], desbloquea: [], semestre: 8 },

  // Quinto año
  // IX Semestre
  { id: 'electiva1', nombre: 'Electiva', uv: 4, requisitos: [], desbloquea: [], semestre: 9 },
  { id: 'electiva2', nombre: 'Electiva', uv: 4, requisitos: [], desbloquea: [], semestre: 9 },
  { id: 'produccion', nombre: 'Gestión de la producción', uv: 4, requisitos: ['cadena', 'plantas'], desbloquea: ['empresarial', 'protocolo'], semestre: 9 },
  { id: 'legislacion', nombre: 'Legislación profesional', uv: 4, requisitos: ['140uv'], desbloquea: ['protocolo', 'empresarial'], semestre: 9 },
  { id: 'proyectos', nombre: 'Formulación y evaluación de proyectos', uv: 4, requisitos: ['mercadeo', 'financiera', 'plantas'], desbloquea: ['implantacion', 'protocolo'], semestre: 9 },

  // X Semestre
  { id: 'electiva3', nombre: 'Electiva', uv: 4, requisitos: [], desbloquea: [], semestre: 10 },
  { id: 'electiva4', nombre: 'Electiva', uv: 4, requisitos: [], desbloquea: [], semestre: 10 },
  { id: 'empresarial', nombre: 'Gestión empresarial', uv: 4, requisitos: ['produccion', 'legislacion'], desbloquea: [], semestre: 10 },
  { id: 'protocolo', nombre: 'Protocolo de trabajo de graduación', uv: 4, requisitos: ['produccion', 'legislacion', 'proyectos'], desbloquea: [], semestre: 10 },
  { id: 'implantacion', nombre: 'Gestión de la implantación de proyectos', uv: 4, requisitos: ['proyectos'], desbloquea: [], semestre: 10 }
];

// Estado para materias
const estadoMaterias = {};
let uvTotal = 0;
const uvText = document.getElementById('uv-total');

// Función para verificar si puedes aprobar (seleccionar) una materia
function puedeAprobar(materia) {
  if (materia.requisitos.includes('140uv')) {
    return uvTotal >= 140;
  }
  return materia.requisitos.every(req => estadoMaterias[req]?.aprobado);
}

// Actualiza bloqueo y desbloqueo visual
function actualizarBloqueos() {
  materias.forEach(materia => {
    const div = estadoMaterias[materia.id].element;
    div.classList.remove('bloqueada');
    if (!estadoMaterias[materia.id].aprobado && !puedeAprobar(materia)) {
      div.classList.add('bloqueada');
    }
  });
}

// Seleccionar materia (clic)
function seleccionarMateria(id) {
  if (!estadoMaterias[id]) return;
  const materia = materias.find(m => m.id === id);
  if (estadoMaterias[id].aprobado) return; // Ya aprobada
  if (!puedeAprobar(materia)) return; // No cumple requisitos

  estadoMaterias[id].aprobado = true;
  estadoMaterias[id].element.classList.add('aprobada');
  uvTotal += materia.uv;
  uvText.textContent = `Total U.V: ${uvTotal}`;
  actualizarBloqueos();
}

// Deseleccionar materia (doble clic)
function deseleccionarMateria(id) {
  if (!estadoMaterias[id]) return;
  if (!estadoMaterias[id].aprobado) return;

  // Para evitar dejar materias dependientes abiertas, podemos verificar si
  // alguna desbloqueada por esta materia está aprobada y bloquear la deselección.
  // Pero para simplicidad, permitiremos deseleccionar siempre.
  estadoMaterias[id].aprobado = false;
  estadoMaterias[id].element.classList.remove('aprobada');
  const materia = materias.find(m => m.id === id);
  uvTotal -= materia.uv;
  uvText.textContent = `Total U.V: ${uvTotal}`;
  actualizarBloqueos();
}

// Renderizar materias en su semestre correspondiente
function renderMaterias() {
  materias.forEach(materia => {
    const div = document.createElement('div');
    div.classList.add('materia');
    div.dataset.id = materia.id;
    div.innerHTML = `
      <div class="nombre">${materia.nombre}</div>
      <div class="uv">${materia.uv} U.V</div>
    `;
    div.addEventListener('click', () => seleccionarMateria(materia.id));
    div.addEventListener('dblclick', () => deseleccionarMateria(materia.id));

    const contenedor = document.getElementById(`semestre-${materia.semestre}`);
    if (contenedor) {
      contenedor.appendChild(div);
      estadoMaterias[materia.id] = { aprobado: false, element: div };
    }
  });
  actualizarBloqueos();
}

document.addEventListener('DOMContentLoaded', () => {
  renderMaterias();
});
